import argparse, json, pandas as pd
from db import insert_record
from models import IngestRecord

parser = argparse.ArgumentParser(description="Import CSV → DB using a mapping file")
parser.add_argument("--file", required=True, help="Path to CSV file")
parser.add_argument("--mapping", required=True, help="Path to field mapping JSON")

if __name__ == "__main__":
    args = parser.parse_args()
    with open(args.mapping) as f:
        mapping = json.load(f)
    df = pd.read_csv(args.file)
    # Map CSV columns → canonical fields
    mapped_cols = {mapping.get(k, k): k for k in df.columns}
    count = 0
    for _, row in df.iterrows():
        rec = IngestRecord(
            external_id=str(row.get(mapping.get("external_id","external_id"), "")),
            name=str(row.get(mapping.get("name","name"), "")),
            email=str(row.get(mapping.get("email","email"), "")),
            phone=str(row.get(mapping.get("phone","phone"), "")),
            notes=str(row.get(mapping.get("notes","notes"), "")),
        )
        insert_record(rec.model_dump())
        count += 1
    print(f"Imported {count} rows ✅")
