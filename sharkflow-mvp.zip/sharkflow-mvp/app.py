from fastapi import FastAPI, Request, UploadFile, Form
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import pandas as pd
from models import IngestRecord, ProcessRequest
from db import create_tables, insert_record, insert_ai_result
from ai import run_ai_enrichment

app = FastAPI(title="Sharkflow MVP")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.on_event("startup")
def startup_event():
    create_tables()

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/api/process")
async def process_records(payload: ProcessRequest):
    saved = 0
    for rec in payload.records:
        rec_id = insert_record(rec.model_dump())
        ai = run_ai_enrichment(rec)
        insert_ai_result(rec_id, {
            "sentiment": ai.sentiment,
            "category": ai.category,
            "risk_score": ai.risk_score,
            "extra_json": str(ai.extra or {})
        })
        saved += 1
    return {"ok": True, "saved": saved}

@app.post("/upload-csv")
async def upload_csv(file: UploadFile):
    df = pd.read_csv(file.file)
    # Expect columns: external_id,name,email,phone,notes (you can change via import script)
    records = []
    for _, row in df.iterrows():
        records.append(IngestRecord(
            external_id=str(row.get("external_id") or ""),
            name=str(row.get("name") or ""),
            email=str(row.get("email") or ""),
            phone=str(row.get("phone") or ""),
            notes=str(row.get("notes") or ""),
        ))
    pr = ProcessRequest(records=records)
    return await process_records(pr)
