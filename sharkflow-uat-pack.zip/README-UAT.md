# Sharkflow UAT Deployment Pack
Generated: 2025-10-23

This pack gives you two easy paths to a UAT/staging site for the FastAPI app in `sharkflow-mvp`.

## Option A — Render (no Docker needed)

1. Push your project (that contains `app.py`, `requirements.txt`, etc.) to GitHub.
2. Add this `render.yaml` to the repo root.
3. In Render dashboard → **New** → **Blueprint** → select your repo.
4. Set environment variables:
   - `DATABASE_URL` (e.g., `postgresql://USER:PASS@HOST:5432/DB` or keep sqlite for quick tests)
   - `OPENAI_API_KEY` (optional for real AI)
5. Deploy. Render will give you a URL like `https://sharkflow-uat.onrender.com`.

## Option B — Fly.io (Dockerfile based)

1. Install Fly CLI: `curl -L https://fly.io/install.sh | sh`
2. In your project root, add the included `Dockerfile` and `fly.toml`.
3. Run:
   ```bash
   fly launch --no-deploy
   fly secrets set DATABASE_URL="sqlite:///sharkflow-uat.db"
   fly secrets set OPENAI_API_KEY="sk-..."
   fly deploy
   ```
4. Fly will return a URL like `https://sharkflow-uat.fly.dev`.

## Custom UAT URL (optional)
- Point `uat.yourdomain.com` CNAME to the Render/Fly hostname.
- Add the domain in the platform dashboard and provision HTTPS.

## Smoke Test
- Open `/` in the browser. You should see the upload form.
- Upload `data/sample.csv` to verify pipeline.
- Check logs for any errors.

## Notes
- For Postgres in UAT, consider **Supabase** or **Render Postgres**.
- Remember to run DB init if you switch from SQLite:
  - Call your init route or run a one-off command to create tables (mirrors `scripts/init_db.py`).